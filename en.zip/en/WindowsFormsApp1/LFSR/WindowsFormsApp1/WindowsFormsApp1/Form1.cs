﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace LFSR
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox1.Text = "就绪";
        }
        
        static string obvtext;    //明文
        static string sectext;   //密文
        static char[] key1 = new char[32];
        static char[] key2 = new char[32];
        static char[] state1 = new char[32];
        static char[] state2 = new char[32];
        static int KEY1;
        static int KEY2;
        static int KEY = 0;

        public static int LFSR1()
        {
            KEY1 = 0;
            for (int i = 31; i >= 0; i--)   //LFSR1输出
            {
                KEY1 = ((key1[i]-'0') * (state1[i]-'0') + KEY1) % 2;
                if (i > 0)
                {
                    state1[i] = state1[i - 1];
                }
                else
                {
                    state1[i] = (char)(KEY1+'0');
                }
            }
            return KEY1;

        }
        public static int LFSR2()
        {
            KEY2 = 0;
            for (int i = 31; i >= 0; i--)   //LFSR2输出
            {
                KEY2 = ((key2[i]-'0') * (state2[i]-'0') + KEY2) % 2;
                if (i > 0)
                {
                    state2[i] = state2[i - 1];
                }
                else
                {
                    state2[i] = (char)(KEY2 + '0');
                }
            }
            return KEY2;
        }
        public static int JK()
        {
            KEY = 0;
            KEY1 = LFSR1();
            KEY2 = LFSR2();
            if (KEY1 == 0 && KEY2 == 1) KEY = 0;
            else if (KEY1 == 1 && KEY2 == 0) KEY = 1;
            else if (KEY1 == 1 && KEY2 == 1) KEY = (KEY+1)%2;
        
            return KEY;
        }
        public static void load_key()          //装载初始密钥
        {
            string k1, k2, s1, s2; 
            string dir = @"C:\Users\lenovo\Desktop\en\LFSR_key1.txt";
            StreamReader sr1 = new StreamReader(dir);
            k1 = sr1.ReadLine();       //载入密钥1
            sr1.Dispose();
            sr1.Close();
            dir = @"C:\Users\lenovo\Desktop\en\LFSR_key2.txt";
            StreamReader sr2 = new StreamReader(dir);
            k2 = sr2.ReadLine();       //载入密钥2
            sr2.Dispose();
            sr2.Close();
            key1 = k1.ToCharArray();
            key2 = k2.ToCharArray();

            dir = @"C:\Users\lenovo\Desktop\en\LFSR_s1.txt";
            StreamReader sr3 = new StreamReader(dir);
            s1 = sr3.ReadLine();       //载入密钥1
            sr3.Dispose();
            sr3.Close();
            dir = @"C:\Users\lenovo\Desktop\en\LFSR_s2.txt";
            StreamReader sr4 = new StreamReader(dir);
            s2 = sr4.ReadLine();       //载入密钥1
            sr4.Dispose();
            sr4.Close();
            //s1 = "11011010111010110001011101011111";
            //s2 = "10100101100101110101100011101000";
            state1 = s1.ToCharArray();
            state2 = s2.ToCharArray();
        }

        private void button1_Click(object sender, EventArgs e)       //加密
        {
            load_key();
            string dir = @"C:\Users\lenovo\Desktop\en\LFSR_plaintext.txt";
            StreamReader sr = new StreamReader(dir, Encoding.Default);   //以unicode的形式读入明文
            obvtext = sr.ReadToEnd();                                   //载入明文
            sr.Close();

            byte[] obvdata = Encoding.Unicode.GetBytes(obvtext);   //把明文字符串转化为字节数组
            string rr = "";
            /*将明文转化成unicode编码的字符流(十六进制）*/
            for (int i = 0; i < obvdata.Length; i += 1)
            {
                rr += obvdata[i].ToString("x").PadLeft(2, '0');      //明文转十六进制2位补零
            }
        
            int len = rr.Length;
            obvtext = "";

            for (int i = 0; i < len; i++)
            {
                int v = Convert.ToInt32(rr[i].ToString(), 16);        //16进制转整数  
                obvtext +=Convert.ToString(v, 2).PadLeft(4, '0');     //整数转二进制4位补齐
            }
            /*具体算法实现*/
            sectext = "";
            for (int i = 0; i < obvtext.Length; i++)
            {   
                int result = ((obvtext[i]-'0') + JK()) % 2;
                sectext += (char)(result+'0');
            }

           
            dir = @"C:\Users\lenovo\Desktop\en\LFSR_code.txt";
            StreamWriter wr = new StreamWriter(dir);    //写进去密文
            wr.Write(sectext);
            wr.Close();
            textBox1.Text = "加密完成";
        }

        private void button2_Click(object sender, EventArgs e)         //解密
        {
            load_key();

            string dir2 = @"C:\Users\lenovo\Desktop\en\LFSR_code.txt";
            StreamReader sr = new StreamReader(dir2,Encoding.Default);
            sectext = sr.ReadToEnd();
            sr.Close();                                            //载入密文
          

            /*解密具体算法实现*/
            obvtext = "";
            int len = sectext.Length;
            for (int i = 0; i < len; i++)
            {
                int result = ((sectext[i]-'0') + JK()) % 2; 
                obvtext += (char)(result + '0');                    //得到二进制字符串
            }

            string temp;
            int len2 = len / 8;
            byte[] obvdata = new byte[len2];
            /*01串转字节数组*/
            for (int i = 0; i < len2; i++)
            {
                temp = obvtext.Substring(i * 8, 8);
                obvdata[i] = Convert.ToByte(temp,2);
            }

            obvtext = Encoding.Unicode.GetString(obvdata);

            dir2 = @"C:\Users\lenovo\Desktop\en\LFSR_plaintext2.txt";
            StreamWriter wr = new StreamWriter(dir2);                //写进明文
            wr.Write(obvtext);
            wr.Close();
            textBox1.Text = "解密完成";
        }
    }
}
