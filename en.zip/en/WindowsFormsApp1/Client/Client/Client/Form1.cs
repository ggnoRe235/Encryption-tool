﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Numerics;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.Security.Cryptography;
using System.Globalization;
using System.IO;

namespace Client
{
    public partial class Form1 : Form
    {
        BackgroundWorker bgWorker = null;
        public static BigInteger receive_root_p = 0;
        public static BigInteger receive_root_e = 0;
        public static BigInteger my_x;
        public static BigInteger half_dh_key;
        public static BigInteger your_half_dh_key;
        public static BigInteger communicate_key=0;
        public static string target_IP = "";
        public static BigInteger your_public_sign_key;
        public static BigInteger my_n = 0;
        public static BigInteger your_n = 0;
        public static string aes_key;
        public static BigInteger public_sign_key;
        public static BigInteger private_sign_key;

        public static BigInteger big_pow(BigInteger cin_a, BigInteger cin_b, BigInteger cin_m)
        {
            //a是底数，b是指数，m是模数
            BigInteger result = 1;
            BigInteger b = cin_b;
            BigInteger a = cin_a;
            while (b != 0)
            {
                BigInteger rm = 0;
                BigInteger.DivRem(b, 2, out rm);
                if (rm == 1)
                {
                    result = BigInteger.Multiply(result, a);
                    BigInteger.DivRem(result, cin_m, out rm);
                    result = rm;
                }
                a = BigInteger.Multiply(a, a);
                BigInteger.DivRem(a, cin_m, out rm);
                a = rm;
                b = BigInteger.Divide(b, 2);
            }
            return result;

        }

        public static bool IsProbablePrime(BigInteger source)
        {
            int certainty = 100;
            if (source == 2 || source == 3)
                return true;
            if (source < 2 || source % 2 == 0)
                return false;

            BigInteger d = source - 1;
            int s = 0;

            while (d % 2 == 0)
            {
                d /= 2;
                s += 1;
            }

            RandomNumberGenerator rng = RandomNumberGenerator.Create();
            byte[] bytes = new byte[source.ToByteArray().LongLength];
            BigInteger a;

            for (int i = 0; i < certainty; i++)
            {
                do
                {
                    rng.GetBytes(bytes);
                    a = new BigInteger(bytes);
                }
                while (a < 2 || a >= source - 2);

                BigInteger x = BigInteger.ModPow(a, d, source);
                if (x == 1 || x == source - 1)
                    continue;

                for (int r = 1; r < s; r++)
                {
                    x = BigInteger.ModPow(x, 2, source);
                    if (x == 1)
                        return false;
                    if (x == source - 1)
                        break;
                }

                if (x != source - 1)
                    return false;
            }

            return true;
        }

        public static void pick_my_x()
        {

            bool flag = false;
            BigInteger p = 0;
            while (!flag)
            {
                Random rd = new Random();
                string temp = "";
                int length = rd.Next(10, 10);
                for (int i = 0; i < length; i++)
                {
                    temp = temp + rd.Next(10);
                }
                p = BigInteger.Parse(temp);
                if (p < receive_root_p) flag = true;
            }
            my_x = p;
            //MessageBox.Show(my_x.ToString());
        }
        /*
        public static string EncryptString(string input, string sKey, string sIV)
        {
            byte[] data = Encoding.Default.GetBytes(input);

            using (DESCryptoServiceProvider des = new DESCryptoServiceProvider())
            {
                des.Key = ASCIIEncoding.Default.GetBytes(sKey);
                des.IV = ASCIIEncoding.Default.GetBytes(sIV);
                ICryptoTransform desencrypt = des.CreateEncryptor();
                byte[] result = desencrypt.TransformFinalBlock(data, 0, data.Length);
                return BitConverter.ToString(result);

            }
        }
        */
        public static string EncryptString(string input, string sKey, string sIV)
        {
            byte[] data = Encoding.Default.GetBytes(input);
            
            using (AesCryptoServiceProvider aes = new AesCryptoServiceProvider())
            {
                aes.Key = ASCIIEncoding.Default.GetBytes(sKey);
                aes.IV = ASCIIEncoding.Default.GetBytes(sIV);
                ICryptoTransform desencrypt = aes.CreateEncryptor();
                byte[] result = desencrypt.TransformFinalBlock(data, 0, data.Length);
                return BitConverter.ToString(result);

            }
        }

        /*
        public static string DecryptString(string input, string sKey, string sIV)
        {
            string[] sInput = input.Split("-".ToCharArray());
            byte[] data = new byte[sInput.Length];
            for (int i = 0; i < sInput.Length; i++)
            {
                data[i] = byte.Parse(sInput[i], NumberStyles.HexNumber);
            }
            using (DESCryptoServiceProvider des = new DESCryptoServiceProvider())
            {
                des.Key = ASCIIEncoding.Default.GetBytes(sKey);
                des.IV = ASCIIEncoding.Default.GetBytes(sIV);
                ICryptoTransform desencrypt = des.CreateDecryptor();
                byte[] result = desencrypt.TransformFinalBlock(data, 0, data.Length);
                return Encoding.Default.GetString(result);
            }

        }
        */

        public static string DecryptString(string input, string sKey, string sIV)
        {
            string[] sInput = input.Split("-".ToCharArray());
            byte[] data = new byte[sInput.Length];
            for (int i = 0; i < sInput.Length; i++)
            {
                data[i] = byte.Parse(sInput[i], NumberStyles.HexNumber);
            }
            using (AesCryptoServiceProvider aes = new AesCryptoServiceProvider())
            {
                aes.Key = ASCIIEncoding.Default.GetBytes(sKey);
                aes.IV = ASCIIEncoding.Default.GetBytes(sIV);
                ICryptoTransform desencrypt = aes.CreateDecryptor();
                byte[] result = desencrypt.TransformFinalBlock(data, 0, data.Length);
                return Encoding.Default.GetString(result);
            }

        }

        public static bool check_sign(string num)
        {
            //MessageBox.Show(num);
            String[] str_buffer = num.Split('|');
            BigInteger half_key = BigInteger.Parse(str_buffer[0]);
            BigInteger rsa_code = BigInteger.Parse(str_buffer[1]);
            BigInteger temp = big_pow(rsa_code, your_public_sign_key, your_n);
            //MessageBox.Show(temp.ToString());
            MD5 md = MD5.Create();
            Byte[] bytes = md.ComputeHash(Encoding.Default.GetBytes(half_key.ToString()));
            BigInteger a = new BigInteger(bytes);
            if (a < 0) a = -a;
            if(a == temp)
            {
                your_half_dh_key = half_key;
                return true;
            }
            else
            {
                return false;
            }

        }

        public static BigInteger generate_big_prime()
        {
            bool flag = false;
            Random rd = new Random();
            BigInteger p = BigInteger.Zero;
            while (!flag)
            {
                string temp = "";
                int length = rd.Next(70 , 75);
                for (int i = 0; i < length; i++)
                {
                    temp = temp + rd.Next(10);
                }

                p = BigInteger.Parse(temp);
                if (IsProbablePrime(p) == true) flag = true;
                else flag = false;
            }
            //MessageBox.Show(p.ToString());
            return p;
        }

        public static bool judge(BigInteger e, BigInteger oler)
        {
            BigInteger r = -1; BigInteger a = e; BigInteger b = oler;
            if (a < b)
            {
                BigInteger temp = a;
                a = b;
                b = temp;
            }
            while (r != 0 && r != 1)
            {
                BigInteger.DivRem(a, b, out r);
                a = BigInteger.Divide(a, b);
                b = r;
            }
            if (r == 0) return false;
            else return true;
        }

        public static BigInteger generate_e(BigInteger oler)
        {
            BigInteger e = BigInteger.Zero;
            bool flag = false;
            Random rd = new Random((int)DateTime.Now.Ticks);
            while (!flag)
            {
                string temp = "";
                int length = rd.Next(6, 8);
                for (int i = 0; i < length; i++)
                {
                    temp = temp + rd.Next(10);
                }
                e = BigInteger.Parse(temp);
                if (judge(e, oler)) flag = true;
                else flag = false;
            }
            //MessageBox.Show(e.ToString());
            return e;
        }

        static private bool calculate(BigInteger a, BigInteger b)
        {
            if (a > b)
            {
                BigInteger temp = b;
                b = a;
                a = temp;
            }
            else if (a < b)
            {
                BigInteger temp = b;
                b = a;
                a = temp;
            }
            else if (a == b)
            {
                return false;
            }
            BigInteger[] shang = new BigInteger[200]; //这里不够可能造成私钥为0
            for (int i = 0; i < 200; i++)
            {
                shang[i] = BigInteger.Zero;
            }
            int count = 0;
            BigInteger aa = a;
            BigInteger r = -1;
            while (true)
            {
                if (r == 1) break;
                if (r == 0) return false;
                shang[count] = a / b;
                count++;
                r = a % b;
                a = b;
                b = r;
            }
            count--;
            BigInteger bl = 1; BigInteger br = shang[count];
            for (int i = 1; i <= count; i++)
            {
                BigInteger temp = shang[count - i] * br + bl;
                bl = br;
                br = temp;
            }
            if ((count + 1) % 2 == 0) private_sign_key = br;
            else if ((count + 1) % 2 == 1) private_sign_key = aa - br;

            return true;
        }

        public static void generate_sign_key()
        {
            BigInteger p, q, n, oler, e = 0;
            p = generate_big_prime();
            q = generate_big_prime();
            n = BigInteger.Multiply(p, q);
            my_n = n;
            oler = BigInteger.Multiply(p - 1, q - 1);
            bool flag = false;
            while (!flag)
            {
                p = generate_big_prime();
                q = generate_big_prime();
                n = BigInteger.Multiply(p, q);
                my_n = n;
                oler = BigInteger.Multiply(p - 1, q - 1);
                e = generate_e(oler);
                public_sign_key = e;
                calculate(public_sign_key, oler);
                if (private_sign_key != 0) flag = true;
            }
            //MessageBox.Show("签名秘钥生成完毕");
            //MessageBox.Show(my_n.ToString());
            //MessageBox.Show(private_sign_key.ToString());
            //MessageBox.Show(public_sign_key.ToString());
        }

        private void bgWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            Socket receiveSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            //IPEndPoint endpoint = new IPEndPoint(IPAddress.Any, 2333);//绑定本机的监听端口
            IPEndPoint endpoint = new IPEndPoint(IPAddress.Any, 2334);
            receiveSocket.Bind(endpoint);
            receiveSocket.Listen(10); //最多可以挂起10个待处理任务
            try
            {
                while (true)
                {
                    Socket tmpSocket = receiveSocket.Accept();
                    byte[] buffer = new byte[tmpSocket.ReceiveBufferSize];
                    tmpSocket.Receive(buffer);
                    if (buffer.Length > 0)
                    {
                        /*MessageBox.Show("New Message, have a check");
                        richTextBox1.Text += DateTime.Now + "\n" + Encoding.Default.GetString(buffer);
                        richTextBox1.Text += "\n";
                        */
                        if (receive_root_p != 0 && receive_root_e != 0 && communicate_key!=0 && your_public_sign_key!=0 && your_n!=0)
                        {
                            //MessageBox.Show("New Message, have a check");
                            string message = Encoding.Default.GetString(buffer);
                            richTextBox1.Text += DateTime.Now + "\n" + DecryptString(message, aes_key, aes_key);
                            richTextBox1.Text += "\n";
                            textBox3.Text = "有新消息";
                        }
                        else if(your_public_sign_key == 0)
                        {
                            string num = Encoding.Default.GetString(buffer);
                            your_public_sign_key = BigInteger.Parse(num);
                            //MessageBox.Show("对方的公钥接收成功");
                        }
                        else if(your_n == 0)
                        {
                            string num = Encoding.Default.GetString(buffer);
                            your_n = BigInteger.Parse(num);
                            //MessageBox.Show("对方的n接收成功");
                            textBox3.Text = "对方公钥模数接受完成";
                        }
                        else if (receive_root_p == 0)
                        {
                            string num = Encoding.Default.GetString(buffer);
                            receive_root_p = BigInteger.Parse(num);
                        }
                        else if (receive_root_e == 0)
                        {
                            string num = Encoding.Default.GetString(buffer);
                            receive_root_e = BigInteger.Parse(num);
                            this.button6.Enabled = true;
                            this.button5.Enabled = true;
                            //MessageBox.Show("本原元接收成功");
                            textBox3.Text = "本原元接受完成";
                        }
                        else if(communicate_key == 0 )
                        {
                            string num = Encoding.Default.GetString(buffer);
                            if(check_sign(num))
                            {
                                //your_half_dh_key = BigInteger.Parse(num);
                                communicate_key = big_pow(your_half_dh_key, my_x, receive_root_p);
                                string k = communicate_key.ToString();
                                for (int i=0;i<16;i++)
                                {
                                    aes_key = aes_key + k[i];
                                }
                                //MessageBox.Show("协商秘钥完成,des_key是" + des_key);
                                textBox3.Text = "秘钥协商完成";
                                StreamWriter wr = new StreamWriter(@"C:\Users\lenovo\Desktop\en\Client.txt");
                                wr.WriteLine("秘钥为" + aes_key);
                                wr.WriteLine("sign_public_key为" + public_sign_key.ToString());
                                wr.Write("sign_private_key为" + private_sign_key.ToString());
                                wr.Close();
                            }
                            else
                            {
                                //MessageBox.Show("错误，重试");
                                textBox3.Text = "错误，重试";
                            }
                        }

                    }
                    else
                    {
                        Thread.Sleep(1000); //将bgWorker挂起1s
                    }

                }

            }
            catch (Exception err)
            {
                MessageBox.Show("Listen fail");
                MessageBox.Show(err.Message);
            }

        }

        public Form1()
        {
            InitializeComponent();
            bgWorker = new BackgroundWorker();
            bgWorker.WorkerSupportsCancellation = true;
            this.bgWorker.DoWork += new DoWorkEventHandler(bgWorker_DoWork);

            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            textBox3.Text = "就绪";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            target_IP = textBox1.Text;
            button2.Enabled = true;
            textBox3.Text = "IP装载完毕";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.button2.Enabled = false;
            this.bgWorker.RunWorkerAsync();
            this.button3.Enabled = true;
            button7.Enabled = true;
            //button8.Enabled = true;
            button6.Enabled = true;
            textBox3.Text = "上线完成";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("登出成功");
            this.bgWorker.CancelAsync();
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Socket sendSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            //sendSocket.Connect(target_IP, 2333);
            sendSocket.Connect(target_IP, 2333);
            string temp = textBox2.Text;
            temp = Dns.GetHostName() + " said : " + temp;
            string temp2 = textBox2.Text;
            temp2 = "I said : " + temp2 + "\n";
            richTextBox1.Text += DateTime.Now + "\n";
            richTextBox1.Text = richTextBox1.Text + temp2;
            string a = EncryptString(temp, aes_key, aes_key);
            byte[] buffer = Encoding.Default.GetBytes(a);
            sendSocket.Send(buffer);
            sendSocket.Shutdown(SocketShutdown.Both);
            sendSocket.Close();
            textBox3.Text = "消息加密发送完成";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            pick_my_x();
            half_dh_key = big_pow(receive_root_e, my_x, receive_root_p);
            //MessageBox.Show("生成dh_key成功");
            
            button6.Enabled = false;
            textBox3.Text = "x^a生成成功";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MD5 md = MD5.Create();
            Byte[] bytes = md.ComputeHash(Encoding.Default.GetBytes(half_dh_key.ToString()));
            BigInteger a = new BigInteger(bytes);
            if (a < 0) a = -a;
            //MessageBox.Show(a.ToString());

            BigInteger send_number = big_pow(a, private_sign_key, my_n);
            string temp = half_dh_key.ToString();
            temp = temp + '|';
            temp = temp + send_number.ToString();
            //MessageBox.Show(temp);

            byte[] buffer = Encoding.Default.GetBytes(temp);
            Socket sendSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            //sendSocket.Connect(target_IP, 2333);
            sendSocket.Connect(target_IP, 2333);
            sendSocket.Send(buffer);
            sendSocket.Shutdown(SocketShutdown.Both);
            sendSocket.Close();
            button4.Enabled = true;
            button5.Enabled = false;

            textBox3.Text = "秘钥协商发送完成";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            generate_sign_key();
            button7.Enabled = false;
            textBox3.Text = "签名秘钥生成完成";
            button8.Enabled = true;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Socket sendSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            
            sendSocket.Connect(target_IP, 2333);
            string temp = "";
            temp = public_sign_key.ToString();
            byte[] buffer = Encoding.Default.GetBytes(temp);
            sendSocket.Send(buffer);
            sendSocket.Shutdown(SocketShutdown.Both);
            sendSocket.Close();

            Socket sendSocket2 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            
            sendSocket2.Connect(target_IP, 2333);
            string temp2 = "";
            temp2 = my_n.ToString();
            byte[] buffer2 = Encoding.Default.GetBytes(temp2);
            sendSocket2.Send(buffer2);
            sendSocket2.Shutdown(SocketShutdown.Both);
            sendSocket2.Close();
            button8.Enabled = false;
            textBox3.Text = "公钥模数发送完成";
            button5.Enabled = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
