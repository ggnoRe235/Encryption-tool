﻿using System.Windows.Forms;
using System.IO;
using System;
using System.Security.Cryptography;
using System.Text;
using System.Globalization;

namespace DESEncrypt
{
    public partial class Form1 : Form
    {

        private static string key;
        private static string IV;

        public Form1()
        {
            InitializeComponent();
            textBox3.Text = "就绪";
        }

        public static string EncryptString(string input, string sKey, string sIV)
        {
            byte[] data = Encoding.Default.GetBytes(input);

            using (DESCryptoServiceProvider des = new DESCryptoServiceProvider())
            {
                des.Key = ASCIIEncoding.Default.GetBytes(sKey);
                des.IV = ASCIIEncoding.Default.GetBytes(sIV);
                ICryptoTransform desencrypt = des.CreateEncryptor();
                byte[] result = desencrypt.TransformFinalBlock(data, 0, data.Length);

                StreamWriter wr = new StreamWriter(@"C:\Users\lenovo\Desktop\en\DES_code.txt");

                string temp = BitConverter.ToString(result);
                wr.Write(temp);
                wr.Close();
                return BitConverter.ToString(result);

            }
        }

        public static void DecryptString(string input, string sKey, string sIV)
        {
            string[] sInput = input.Split("-".ToCharArray());
            byte[] data = new byte[sInput.Length];
            for (int i = 0; i < sInput.Length; i++)
            {
                data[i] = byte.Parse(sInput[i], NumberStyles.HexNumber);
            }
            using (DESCryptoServiceProvider des = new DESCryptoServiceProvider())
            {
                des.Key = ASCIIEncoding.Default.GetBytes(sKey);
                des.IV = ASCIIEncoding.Default.GetBytes(sIV);
                ICryptoTransform desencrypt = des.CreateDecryptor();
                byte[] result = desencrypt.TransformFinalBlock(data, 0, data.Length);
                StreamWriter wr = new StreamWriter(@"C:\Users\lenovo\Desktop\en\DES_plaintext2.txt");
                wr.Write(Encoding.Default.GetString(result));
                wr.Close();
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            key = textBox1.Text;
            IV = textBox2.Text;
            if (key == "")
            {
                textBox3.Text = "秘钥未输入";
            }
            else
            {
                string plaintext;
                plaintext = "";
                StreamReader sr = new StreamReader(@"C:\Users\lenovo\Desktop\en\DES_plaintext.txt", System.Text.Encoding.Default);
                plaintext = sr.ReadToEnd();
                sr.Close();
                string result = EncryptString(plaintext, key, IV);
                textBox3.Text = "加密完成";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            key = textBox1.Text;
            IV = textBox2.Text;
            if (key == "")
            {
                textBox3.Text = "未输入秘钥";
            }
            else
            {
                string codetext = "";
                StreamReader sr = new StreamReader(@"C:\Users\lenovo\Desktop\en\DES_code.txt", Encoding.Default);
                codetext = sr.ReadToEnd();
                sr.Close();
                DecryptString(codetext, key, IV);
                textBox3.Text = "解密完成";
            }
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)//明文
        {

        }
    }
}
