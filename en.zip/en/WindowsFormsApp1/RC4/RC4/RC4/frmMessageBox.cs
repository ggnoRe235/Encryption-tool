﻿using System.Drawing;
using System.Windows.Forms;

namespace RC4
{
    public partial class frmMessageBox : Form
    {
        public frmMessageBox(string msg)
        {
            //InitializeComponent();

            this.Text = "提示";
            this.Font=new Font("宋体",50, FontStyle.Regular);
            
        }
    }
}
