﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace RC4
{
    public partial class Form1 : Form
    {
        int[] s = new int[256];  //S盒
        int[] key = new int[8];  //8位密钥
        string m;  //明文
        string code;  //密文
        string ckey;  //密钥

        public Form1()
        {
            InitializeComponent();
            textBox1.Text = "就绪";
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            //由于技术有限，先固定密钥
            /*for(int i=0;i<8;i++)
            {
                key[i] = i;
            }*/
            //读取密钥
            StreamReader sr = new StreamReader(@"C:\Users\lenovo\Desktop\en\RC4_key.txt");
            ckey = sr.ReadToEnd();
            sr.Close();
            //密钥字符转密钥数组
            char[] keys = ckey.ToCharArray();
            /*for(int i=0;i<keys.Length;i++)
            {
                MessageBox.Show(keys[i].ToString());
            }*/
            int l = 0;
            for (int i=0;i<8;i++)
            {
                key[i] = (keys[l]-48)*100 + (keys[l + 1]-48)*10 + (keys[l + 2]-48);
                l=l+3;
                //key[i] = keys[i]-48;
                //MessageBox.Show(key[i].ToString());
            }
            //初始化S盒
            for(int i=0;i<256;i++)
            {
                s[i] = i;
            }
            //置换S盒，KSA算法
            int tmp;
            int j = 0;
            int k = 0;
            for(int i=0;i<256;i++)
            {
                tmp = s[i];
                j = (j + tmp + key[k]);
                if(j>=256)
                {
                    j = j % 256;
                }
                s[i] = s[j];
                s[j] = tmp;
                k = k + 1;
                if(k>=8)  //如果要修改密钥长度，这里也要修改
                {
                    k = 0;
                }
            }
            //frmMessageBox mybox = new frmMessageBox("密钥读入成功！");
            //mybox.Show();
            //mybox.ShowDialog();
            textBox1.Text = "密钥读入成功";
            button2.Enabled = true;
            button3.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader(@"C:\Users\lenovo\Desktop\en\RC4_plaintext.txt",Encoding.Default);
            m = sr.ReadToEnd();
            sr.Close();
            //明文转数组
            char[] datas = m.ToCharArray();
            int[] mingwen = new int[datas.Length];
            for(int i=0;i<datas.Length;i++)
            {
                //mingwen[i] = datas[i];
                mingwen[i] = Convert.ToInt32(datas[i]);
            }
            //根据256位密钥数组和明文数组得到密文数组
            int x = 0, y = 0, a, b, c;
            int len = mingwen.Length;
            int[] miwen = new int[len];
            for(int i=0;i<len;i++)
            {
                x = (x + 1) % 256;
                a = s[x];
                y = (y + a)%256;
                b = s[y];
                s[x] = b;
                s[y] = a;
                c = (a + b)%256;
                miwen[i] = mingwen[i] ^ s[c];
            }
            //密文数组转密文字符
            char[] mi = new char[miwen.Length];
            for(int i=0;i<miwen.Length;i++)
            {
                //mi[i] = (char)miwen[i];
                mi[i] = Convert.ToChar(miwen[i]);
            }
            string miwenstr = new string(mi);
            StreamWriter sw = new StreamWriter(@"C:\Users\lenovo\Desktop\en\RC4_code.txt");
            sw.Write(miwenstr);
            sw.Close();
            //MessageBox.Show("明文加密完毕！");
            textBox1.Text = "加密完成";
            button3.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader(@"C:\Users\lenovo\Desktop\en\RC4_code.txt");
            code = sr.ReadToEnd();
            sr.Close();
            //密文字符转密文数组
            Char[] datas = code.ToCharArray();
            int[] miwen = new int[datas.Length];
            for(int i=0;i<datas.Length;i++)
            {
                miwen[i] = datas[i];
            }
            //根据256位密钥数组和密文数组得到明文数组
            int x = 0, y = 0, a, b, c;
            int len = miwen.Length;
            int[] mingwen = new int[len];
            for (int i = 0; i < len; i++)
            {
                x = (x + 1) % 256;
                a = s[x];
                y = (y + a) % 256;
                b = s[y];
                s[x] = b;
                s[y] = a;
                c = (a + b) % 256;
                mingwen[i] = miwen[i] ^ s[c];
            }
            //明文数组转明文字符
            char[] ming = new char[mingwen.Length];
            for(int i=0;i<mingwen.Length;i++)
            {
                ming[i] = (char)mingwen[i];
            }
            string str = new string(ming);
            StreamWriter sw = new StreamWriter(@"C:\Users\lenovo\Desktop\en\RC4_plaintext2.txt");
            sw.Write(str);
            sw.Close();
            //MessageBox.Show("密文解密完毕！");
            button2.Enabled = false;
            textBox1.Text = "解密完成";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button1.Enabled = true;
            button2.Enabled = false;
            button3.Enabled = false;
        }
    }
}
