﻿using System;
using System.IO;
using System.Windows.Forms;

namespace Affine
{
    public partial class Affine : Form
    {
        static string plaintext;
        static string code;
        static int key1;
        static int key2;
        static int key1_;

        /*public static bool calculate(int M, int m) //计算逆元 
        {
            M = M % m;
            if (M == 1) key1_=1;
            int count = 0;
            int[] number = new int[100];
            for (int i = 0; i < 100; i++) number[i] = 0;
            int r = -1; int N = m; int a = M;
            while (r != 1 && r != 0)
            {
                number[count] = N / a;
                r = N % a;
                N = a;
                a = r;
                count++;
            }
            if (r == 0) return false;
            count--;
            int b_ = -1;
            int[] b = new int[count];
            for (int i = 0; i < count; i++) b[i] = 0;
            b[0] = number[count];
            for (int i = 1; i < count; i++)
            {
                if (i == 1)
                {
                    b[i] = number[count] * b[i - 1] + b_;
                }
                else
                {
                    b[i] = number[count - i] * b[i - 1] + b[i - 2];
                }
            }
            MessageBox.Show(b[count].ToString());
            if (count % 2 == 1) key1_ = b[count-1];
            else if (count % 2 == 0) key1_ = m - b[count-1];
            return true;
        }
        \*/
        static private bool calculate(int a, int b)
        {
            if (a > b)
            {
                int temp = b;
                b = a;
                a = temp;
            }
            else if (a < b)
            {
                int temp = b;
                b = a;
                a = temp;
            }
            else if (a == b)
            {
                return false;
            }
            int[] shang = new int[1000];
            for (int i = 0; i < 1000; i++)
            {
                shang[i] = 0;
            }

            int count = 0;
            int aa = a;
            int r = -1;
            while (true)
            {
                if (r == 1) break;
                if (r == 0) return false;
                shang[count] = a / b;
                count++;
                r = a % b;
                a = b;
                b = r;
            }
            count--;
            int bl = 1; int br = shang[count];
            for (int i = 1; i <= count; i++)
            {
                int temp = shang[count - i] * br + bl;
                bl = br;
                br = temp;
            }
            if ((count + 1) % 2 == 0) key1_ = br;
            else if ((count + 1) % 2 == 1) key1_ = aa - br;
            return true;
        }

        public Affine()
        {
            InitializeComponent();
        }



        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                textBox3.Text = "输入错误，重新输入";
            }
            else
            {
                key1 = Convert.ToInt32(textBox1.Text);
                key2 = Convert.ToInt32(textBox2.Text);
                button3.Enabled = true;
                button4.Enabled = true;
                textBox3.Text = "秘钥装载完成";
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            plaintext = "";
            code = "";
            StreamReader sr = new StreamReader(@"C:\Users\lenovo\Desktop\en\Affine_plaintext.txt");
            plaintext = sr.ReadToEnd();
            sr.Close();
            int length = plaintext.Length;
            int number = 0;

            for (int i=0;i<length;i++)
            {
                number = plaintext[i] - 'a';
                code = code + (char)((key1 * number + key2) % 26 + 'a');
            }
            StreamWriter wr = new StreamWriter(@"C:\Users\lenovo\Desktop\en\Affine_code.txt");
            wr.Write(code);
            wr.Close();
            textBox3.Text = "加密完成";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            bool judge = calculate(key1 , 26);
            //bool judge = true;
            if (judge)
            {
                //key1_ = 9;
                int number = 0;
                plaintext = "";
                code = "";
                StreamReader sr = new StreamReader(@"C:\Users\lenovo\Desktop\en\Affine_code.txt");
                code = sr.ReadToEnd();
                sr.Close();
                for (int i = 0; i < code.Length; i++)
                {
                    number = code[i] - 'a';
                    plaintext = plaintext + (char)((key1_ * ((number - key2 + 26) %26)  ) % 26 + 'a');
                }
                StreamWriter wr = new StreamWriter(@"C:\Users\lenovo\Desktop\en\Affine_plaintext2.txt");
                wr.Write(plaintext);
                wr.Close();
                textBox3.Text = "解密完成";
            }
            else
            {
                textBox3.Text = "不互素";
            }
        }

        private void Affine_Load(object sender, EventArgs e)
        {
            button3.Enabled = false;
            button4.Enabled = false;
            textBox3.Text = "就绪";
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
