﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using RSA;
using Affine;
using DESEncrypt;
using RC4;
using LFSR;
using Server;
using Client;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public static Thread thread_affine=null;
        public static Thread thread_des=null;
        public static Thread thread_rc4=null;
        public static Thread thread_rsa=null;
        public static Thread thread_lfsr=null;
        public static Thread thread_dh_s = null;
        public static Thread thread_dh_c = null;

        public Form1()
        {
            InitializeComponent();
        }

        public static void start_affine()
        {
            Application.Run(new Affine.Affine());
        }

        public static void start_des()
        {
            Application.Run(new DESEncrypt.Form1());
        }

        public static void start_rc4()
        {
            Application.Run(new RC4.Form1());
        }

        public static void start_rsa()
        {
            Application.Run(new RSA.Form1());
        }

        public static void start_lfsr()
        {
            Application.Run(new LFSR.Form1());
        }

        public static void start_server()
        {
            Application.Run(new Server.Form1());
        }

        public static void start_client()
        {
            Application.Run(new Client.Form1());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //使用仿射加密
            thread_affine = new Thread(start_affine);
            thread_affine.Start();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            thread_des = new Thread(start_des);
            thread_des.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            thread_rc4 = new Thread(start_rc4);
            thread_rc4.Start();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            thread_rsa = new Thread(start_rsa);
            thread_rsa.Start();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            thread_lfsr = new Thread(start_lfsr);
            thread_lfsr.Start();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (thread_affine != null) if (thread_affine.IsAlive) thread_affine.Abort();
            if (thread_des != null) if (thread_des.IsAlive) thread_des.Abort();
            if (thread_lfsr != null) if (thread_lfsr.IsAlive) thread_lfsr.Abort();
            if (thread_rc4 != null) if (thread_rc4.IsAlive) thread_rc4.Abort();
            if (thread_rsa != null) if (thread_rsa.IsAlive) thread_rsa.Abort();
            if (thread_dh_s != null) if (thread_dh_s.IsAlive) thread_dh_s.Abort();
            if (thread_dh_c != null) if (thread_dh_c.IsAlive) thread_dh_c.Abort();
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            thread_dh_s = new Thread(start_server);
            thread_dh_s.Start();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            thread_dh_c = new Thread(start_client);
            thread_dh_c.Start();
        }
    }
}
