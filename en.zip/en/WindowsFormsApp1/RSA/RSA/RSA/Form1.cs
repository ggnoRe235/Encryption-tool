﻿using System;
using System.Windows.Forms;
using System.Numerics;
using System.IO;
using System.Text;
using System.Threading;
using System.Security.Cryptography;

namespace RSA
{
    public partial class Form1 : Form
    {
        public static BigInteger oler = BigInteger.Zero;
        public static BigInteger number_e = BigInteger.Zero;
        public static BigInteger d = BigInteger.Zero;
        public static BigInteger numer = BigInteger.Zero;
        //public static Thread thread;

        static private bool calculate(BigInteger a, BigInteger b)
        {
            if (a > b)
            {
                BigInteger temp = b;
                b = a;
                a = temp;
            }
            else if (a < b)
            {
                BigInteger temp = b;
                b = a;
                a = temp;
            }
            else if (a == b)
            {
                return false;
            }
            BigInteger[] shang = new BigInteger[200]; //这里不够可能造成私钥为0
            for (int i = 0; i < 200; i++)
            {
                shang[i] = BigInteger.Zero;
            }
            int count = 0;
            BigInteger aa = a;
            BigInteger r = -1;
            while (true)
            {
                if (r == 1) break;
                if (r == 0) return false;
                shang[count] = a / b;
                count++;
                r = a % b;
                a = b;
                b = r;
            }
            count--;
            BigInteger bl = 1; BigInteger br = shang[count];
            for (int i = 1; i <= count; i++)
            {
                BigInteger temp = shang[count - i] * br + bl;
                bl = br;
                br = temp;
            }
            if ((count + 1) % 2 == 0) d = br;
            else if ((count + 1) % 2 == 1) d = aa - br;

            return true;
        }

        public static bool IsProbablePrime(BigInteger source)
        {
            int certainty = 100;
            if (source == 2 || source == 3)
                return true;
            if (source < 2 || source % 2 == 0)
                return false;

            BigInteger d = source - 1;
            int s = 0;

            while (d % 2 == 0)
            {
                d /= 2;
                s += 1;
            }

            RandomNumberGenerator rng = RandomNumberGenerator.Create();
            byte[] bytes = new byte[source.ToByteArray().LongLength];
            BigInteger a;

            for (int i = 0; i < certainty; i++)
            {
                do
                {
                    rng.GetBytes(bytes);
                    a = new BigInteger(bytes);
                }
                while (a < 2 || a >= source - 2);

                BigInteger x = BigInteger.ModPow(a, d, source);
                if (x == 1 || x == source - 1)
                    continue;

                for (int r = 1; r < s; r++)
                {
                    x = BigInteger.ModPow(x, 2, source);
                    if (x == 1)
                        return false;
                    if (x == source - 1)
                        break;
                }

                if (x != source - 1)
                    return false;
            }

            return true;
        }

        public static BigInteger generate_p()
        {
            bool flag = false;
            Random rd = new Random();
            BigInteger p = BigInteger.Zero;
            while (!flag)
            {
                string temp = "";
                int length = rd.Next(95, 100);
                for (int i = 0; i < length; i++)
                {
                    temp = temp + rd.Next(10);
                }

                p = BigInteger.Parse(temp);
                if (IsProbablePrime(p) == true) flag = true;
                else flag = false;
            }
            //MessageBox.Show(p.ToString());
            return p;
        }

        public static bool judge(BigInteger e, BigInteger oler)
        {
            BigInteger r = -1; BigInteger a = e; BigInteger b = oler;
            if (a < b)
            {
                BigInteger temp = a;
                a = b;
                b = temp;
            }
            while (r != 0 && r != 1)
            {
                BigInteger.DivRem(a, b, out r);
                a = BigInteger.Divide(a, b);
                b = r;
            }
            if (r == 0) return false;
            else return true;
        }

        public static BigInteger generate_e()
        {

            BigInteger e = BigInteger.Zero;
            bool flag = false;
            Random rd = new Random();
            while (!flag)
            {
                string temp = "";
                int length = rd.Next(6, 8);
                for (int i = 0; i < length; i++)
                {
                    temp = temp + rd.Next(10);
                }
                e = BigInteger.Parse(temp);
                if (judge(e, oler)) flag = true;
                else flag = false;
            }
            //MessageBox.Show(e.ToString());
            return e;
        }

        public Form1()
        {
            InitializeComponent();
        }

        public static BigInteger encode(BigInteger M)
        {
            BigInteger code = BigInteger.Zero;
            BigInteger cache_e = number_e;
            BigInteger a = 1;
            BigInteger b = M;
            while (cache_e != 0)
            {
                BigInteger rm = 0;
                BigInteger.DivRem(cache_e, 2, out rm);
                if (rm == 1)
                {
                    a = BigInteger.Multiply(a, b);
                    BigInteger.DivRem(a, numer, out rm);
                    a = rm;
                }
                b = BigInteger.Multiply(b, b);
                BigInteger.DivRem(b, numer, out rm);
                b = rm;
                cache_e = BigInteger.Divide(cache_e, 2);
            }
            code = a;
            return code;
        }

        public static BigInteger decode(BigInteger M)
        {
            BigInteger code = BigInteger.Zero;
            BigInteger cache_e = d;
            BigInteger a = 1;
            BigInteger b = M;
            while (cache_e != 0)
            {
                BigInteger rm = 0;
                BigInteger.DivRem(cache_e, 2, out rm);
                if (rm == 1)
                {
                    a = BigInteger.Multiply(a, b);
                    BigInteger.DivRem(a, numer, out rm);
                    a = rm;
                }
                b = BigInteger.Multiply(b, b);
                BigInteger.DivRem(b, numer, out rm);
                b = rm;
                cache_e = BigInteger.Divide(cache_e, 2);
            }
            code = a;
            return code;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button4.Enabled = false;
            textBox7.Text = "就绪";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            BigInteger p = generate_p();
            BigInteger q = generate_p();
            BigInteger n = BigInteger.Multiply(p, q);
            numer = n;
            oler = BigInteger.Multiply(p - 1, q - 1);
            number_e = generate_e();
            calculate(number_e, oler);
            while (d == 0)
            {

                p = generate_p();
                q = generate_p();
                n = BigInteger.Multiply(p, q);
                numer = n;
                oler = BigInteger.Multiply(p - 1, q - 1);
                number_e = generate_e();
                calculate(number_e, oler);
            }
            textBox1.Text = p.ToString();
            textBox2.Text = q.ToString();
            textBox3.Text = n.ToString();
            textBox4.Text = oler.ToString();
            textBox5.Text = number_e.ToString();
            textBox6.Text = d.ToString();
            button4.Enabled = true;
            textBox7.Text = "秘钥生成完成";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //8个字一组
            StreamReader cin = new StreamReader(@"C:\Users\lenovo\Desktop\en\RSA_plaintext.txt", Encoding.Default);
            string text = cin.ReadToEnd();
            cin.Close();

            int num_of_t = 0;
            if (text.Length % 8 == 0) num_of_t = text.Length / 8;
            else if (text.Length % 8 != 0) num_of_t = (text.Length / 8) + 1;

            string[] str_team = new string[num_of_t];
            if (text.Length % 8 == 0)
            {
                for (int i = 0; i < num_of_t; i++)
                {
                    for (int m = 0; m < 8; m++)
                    {
                        str_team[i] = str_team[i] + text[i * 8 + m];
                    }
                }
            }
            else if (text.Length % 8 != 0)
            {
                for (int i = 0; i < num_of_t; i++)
                {
                    if (i != num_of_t - 1)
                    {
                        for (int m = 0; m < 8; m++)
                        {
                            str_team[i] = str_team[i] + text[i * 8 + m];
                        }
                    }
                    else
                    {
                        for (int m = 0; m < text.Length % 8; m++)
                        {
                            str_team[i] = str_team[i] + text[i * 8 + m];
                        }
                    }
                }
            }
            /*
            for(int i=0;i<num_of_t;i++)
            {
                MessageBox.Show(str_team[i]);
            }
            */
            BigInteger[] big_plaintext = new BigInteger[num_of_t];
            for (int i = 0; i < num_of_t; i++)
            {
                Byte[] b = Encoding.Default.GetBytes(str_team[i]);
                big_plaintext[i] = new BigInteger(b);
            }

            BigInteger[] big_code = new BigInteger[num_of_t];
            for (int i = 0; i < num_of_t; i++)
            {
                big_code[i] = encode(big_plaintext[i]);
            }

            StreamWriter streamwriter = new StreamWriter(@"C:\Users\lenovo\Desktop\en\RSA_code.txt");
            for (int i = 0; i < num_of_t; i++)
            {
                streamwriter.WriteLine(big_code[i].ToString());
            }
            streamwriter.Close();


            BigInteger[] r_big_plaintext = new BigInteger[num_of_t];
            StreamReader sr = new StreamReader(@"C:\Users\lenovo\Desktop\en\RSA_code.txt", Encoding.Default);
            for (int i = 0; i < num_of_t; i++)
            {
                r_big_plaintext[i] = BigInteger.Parse(sr.ReadLine());
            }
            sr.Close();
            for (int i = 0; i < num_of_t; i++)
            {
                r_big_plaintext[i] = decode(big_code[i]);
            }

            string[] r_plaintext = new string[num_of_t];
            for (int i = 0; i < num_of_t; i++)
            {
                Byte[] b = r_big_plaintext[i].ToByteArray();
                r_plaintext[i] = Encoding.Default.GetString(b);
            }
            string fi = "";
            for (int i = 0; i < num_of_t; i++)
            {
                fi = fi + r_plaintext[i];
            }

            StreamWriter sw = new StreamWriter(@"C:\Users\lenovo\Desktop\en\RSA_plaintext2.txt");
            sw.Write(fi);
            sw.Close();
            textBox7.Text = "加解密完成";

            //MessageBox.Show(fi);
            /*Byte[] b = Encoding.Default.GetBytes(text);
            MessageBox.Show(Encoding.Default.GetString(b));
            BigInteger plaintext = new BigInteger(b);
            BigInteger code = encode(plaintext);
            plaintext = 0;
            plaintext = decode(code);
            Byte [] bb = plaintext.ToByteArray();
            string fi = Encoding.Default.GetString(bb);
            MessageBox.Show(fi);*/

        }
    }
}
