﻿using System;

public class Affine
{
	public Affine()
	{
	}
}
